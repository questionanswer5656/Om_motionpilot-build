# Engineering notes

## Persistence modules

`GestureEngineService` is the primary persistent execution layer.

`BootReceiver` handles BOOT_COMPLETED, LOCKED_BOOT_COMPLETED and MY_PACKAGE_REPLACED when the saved engine state is enabled.

`DeviceCapabilities` detects sensor/OEM capabilities.

`OemGuidance` gives device-family-specific battery/background steps.

The design intentionally avoids claiming universal self-restart after explicit user stop.

## Recognition design

The detector is intentionally conservative. It requires alternating directional impulses or sustained opposite strokes. Pocket proximity and recent step events increase the threshold instead of disabling the engine.

## Edge controls

Edge controls use a transparent `TYPE_APPLICATION_OVERLAY` strip. They require the user's explicit overlay permission. Lock-screen interaction is device/OS dependent and must be certified; the motion engine itself does not require the overlay.

## Production hardening still required

- Real-device benchmark and false-trigger dataset.
- OEM-by-OEM background-policy automation and regression tests.
- More robust world-orientation normalization if the product needs orientation-independent gestures.
- Production logging and privacy review.
- Play Console foreground-service declaration/review for `specialUse`.
- Final action-by-action Android 17 compatibility testing, especially volume/ringer interactions.
