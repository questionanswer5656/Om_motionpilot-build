# MotionPilot currently uses no reflection-based shrinking rules.
# Keep this file so release builds have a stable ProGuard/R8 entry point.
