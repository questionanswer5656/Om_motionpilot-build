package com.motionpilot.gesture.app;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.provider.Settings;

public final class PermissionManager {
    private PermissionManager() {}

    public static boolean notificationsGranted(Context c) {
        if (Build.VERSION.SDK_INT < 33) return true;
        return c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean callGranted(Context c) {
        return c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean activityRecognitionGranted(Context c) {
        if (Build.VERSION.SDK_INT < 29) return true;
        return c.checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED;
    }

    public static boolean overlayGranted(Context c) {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(c);
    }

    public static void requestRuntime(Activity a, String permission, int requestCode) {
        if (Build.VERSION.SDK_INT >= 23 && a.checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) {
            a.requestPermissions(new String[]{permission}, requestCode);
        }
    }
}
