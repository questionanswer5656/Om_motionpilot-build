package com.motionpilot.gesture.core;

public final class MotionSample {
    public final long timeMs;
    public final float x;
    public final float y;
    public final float z;

    public MotionSample(long timeMs, float x, float y, float z) {
        this.timeMs = timeMs;
        this.x = x;
        this.y = y;
        this.z = z;
    }
}
