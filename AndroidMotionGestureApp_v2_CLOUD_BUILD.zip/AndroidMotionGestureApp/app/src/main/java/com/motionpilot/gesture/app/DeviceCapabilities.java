package com.motionpilot.gesture.app;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Build;
import android.provider.Settings;
import android.view.WindowManager;

public final class DeviceCapabilities {
    public final int apiLevel = Build.VERSION.SDK_INT;
    public final String manufacturer = Build.MANUFACTURER == null ? "Unknown" : Build.MANUFACTURER;
    public final String model = Build.MODEL == null ? "Unknown" : Build.MODEL;
    public final Sensor accelerometer;
    public final Sensor proximity;
    public final Sensor stepDetector;
    public final Sensor gyroscope;
    public final boolean overlayGranted;

    public DeviceCapabilities(Context context) {
        SensorManager sm = (SensorManager) context.getSystemService(Context.SENSOR_SERVICE);
        Sensor wakeAccel = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER, true);
        accelerometer = wakeAccel != null ? wakeAccel : (sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER));
        proximity = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_PROXIMITY);
        stepDetector = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
        gyroscope = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        overlayGranted = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(context);
    }

    public boolean hasMotionSensor() { return accelerometer != null; }
    public boolean hasProximity() { return proximity != null; }
    public boolean hasWalkingSensor() { return stepDetector != null; }
    public String brand() { return manufacturer.toLowerCase(); }
    public boolean isSamsung() { return brand().contains("samsung"); }
    public boolean isXiaomiFamily() { return brand().contains("xiaomi") || brand().contains("redmi") || brand().contains("poco"); }
    public boolean isOnePlus() { return brand().contains("oneplus"); }
    public boolean isOppo() { return brand().contains("oppo"); }
    public boolean isVivo() { return brand().contains("vivo"); }
    public boolean isRealme() { return brand().contains("realme"); }
    public boolean isMotorola() { return brand().contains("motorola"); }
    public boolean isHonor() { return brand().contains("honor"); }
}
