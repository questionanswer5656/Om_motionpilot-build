package com.motionpilot.gesture.app;

import android.content.Context;
import android.content.SharedPreferences;

import com.motionpilot.gesture.model.ActionType;
import com.motionpilot.gesture.model.GestureType;

public final class AppPreferences {
    private static final String PREFS = "motionpilot_prefs";
    private final SharedPreferences prefs;

    public AppPreferences(Context context) {
        Context storage = android.os.Build.VERSION.SDK_INT >= 24 ? context.createDeviceProtectedStorageContext() : context;
        prefs = storage.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean isEngineEnabled() { return prefs.getBoolean("engine_enabled", false); }
    public void setEngineEnabled(boolean enabled) { prefs.edit().putBoolean("engine_enabled", enabled).apply(); }

    public boolean isEdgeEnabled() { return prefs.getBoolean("edge_enabled", false); }
    public void setEdgeEnabled(boolean enabled) { prefs.edit().putBoolean("edge_enabled", enabled).apply(); }

    public String getLeftEdgeAction() { return prefs.getString("left_edge_action", "FLASHLIGHT"); }
    public String getRightEdgeAction() { return prefs.getString("right_edge_action", "VOLUME"); }

    public void setGestureAction(GestureType type, ActionType action) {
        prefs.edit().putString("gesture_action_" + type.name(), action.name()).apply();
    }

    public ActionType getGestureAction(GestureType type) {
        String value = prefs.getString("gesture_action_" + type.name(), null);
        if (value == null) return defaultAction(type);
        try { return ActionType.valueOf(value); } catch (IllegalArgumentException e) { return ActionType.NONE; }
    }

    public void setPayload(GestureType type, String payload) {
        prefs.edit().putString("gesture_payload_" + type.name(), payload == null ? "" : payload).apply();
    }

    public String getPayload(GestureType type) {
        return prefs.getString("gesture_payload_" + type.name(), "");
    }

    public SharedPreferences prefsForInternalOnly() {
        return prefs;
    }

    public void resetGestureDefaults() {
        SharedPreferences.Editor e = prefs.edit();
        for (GestureType type : GestureType.values()) {
            e.putString("gesture_action_" + type.name(), defaultAction(type).name());
            e.remove("gesture_payload_" + type.name());
        }
        e.apply();
    }

    private ActionType defaultAction(GestureType type) {
        switch (type) {
            case HORIZONTAL_DOUBLE: return ActionType.FLASHLIGHT_TOGGLE;
            case HORIZONTAL_TRIPLE: return ActionType.FLASHLIGHT_BRIGHTER;
            case VERTICAL_DOUBLE: return ActionType.VOLUME_UP;
            case VERTICAL_TRIPLE: return ActionType.VOLUME_DOWN;
            case LONG_VERTICAL: return ActionType.RINGER_VIBRATE;
            case LONG_HORIZONTAL: return ActionType.RINGER_NORMAL;
            default: return ActionType.NONE;
        }
    }
}
