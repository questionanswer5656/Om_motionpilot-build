package com.motionpilot.gesture.service;

import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;

import com.motionpilot.gesture.app.AppPreferences;

public final class EdgeOverlayController {
    private final GestureEngineService service;
    private final WindowManager wm;
    private final AppPreferences prefs;
    private View left;
    private View right;

    public EdgeOverlayController(GestureEngineService service) {
        this.service = service;
        wm = (WindowManager) service.getSystemService(GestureEngineService.WINDOW_SERVICE);
        prefs = new AppPreferences(service);
    }

    public void startIfAllowed() {
        if (!prefs.isEdgeEnabled()) return;
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(service)) return;
        if (left != null || right != null) return;
        left = createEdge(true);
        right = createEdge(false);
        add(left, Gravity.START);
        add(right, Gravity.END);
    }

    public void stop() {
        if (left != null) { remove(left); left = null; }
        if (right != null) { remove(right); right = null; }
    }

    private View createEdge(final boolean isLeft) {
        FrameLayout v = new FrameLayout(service);
        v.setBackgroundColor(Color.TRANSPARENT);
        v.setOnTouchListener(new View.OnTouchListener() {
            float downY;
            long downT;
            @Override public boolean onTouch(View view, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downY = e.getRawY();
                        downT = System.currentTimeMillis();
                        return true;
                    case MotionEvent.ACTION_UP:
                        float dy = e.getRawY() - downY;
                        long dt = Math.max(1L, System.currentTimeMillis() - downT);
                        if (Math.abs(dy) >= dp(80) && dt <= 1000) {
                            if (isLeft) {
                                service.onLeftEdgeSwipe(dy < 0);
                            } else {
                                service.onRightEdgeSwipe(dy < 0);
                            }
                        }
                        return true;
                    default:
                        return true;
                }
            }
        });
        return v;
    }

    private void add(View v, int gravity) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                dp(26), WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED,
                PixelFormat.TRANSLUCENT);
        p.gravity = gravity;
        wm.addView(v, p);
    }

    private void remove(View v) {
        try { wm.removeView(v); } catch (IllegalArgumentException ignored) { }
    }

    private int dp(int value) {
        return Math.round(value * service.getResources().getDisplayMetrics().density);
    }
}
