package com.motionpilot.gesture.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

import com.motionpilot.gesture.app.AppPreferences;

public final class BootReceiver extends BroadcastReceiver {
    private static final String TAG = "MotionPilot";

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? "" : intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_LOCKED_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) return;
        AppPreferences prefs = new AppPreferences(context);
        if (!prefs.isEngineEnabled()) return;
        try {
            Intent service = new Intent(context, GestureEngineService.class);
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
            else context.startService(service);
        } catch (Exception e) {
            Log.w(TAG, "Boot recovery could not start the gesture engine", e);
        }
    }
}
