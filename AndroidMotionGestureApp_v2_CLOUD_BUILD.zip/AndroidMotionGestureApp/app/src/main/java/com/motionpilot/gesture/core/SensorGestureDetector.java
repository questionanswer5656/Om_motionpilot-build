package com.motionpilot.gesture.core;

import com.motionpilot.gesture.model.GestureType;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Lightweight deliberate-motion recognizer. It intentionally ignores tiny taps and
 * one-direction bumps. It uses event shape, threshold, sign changes, duration and
 * timing rather than raw motion count.
 */
public final class SensorGestureDetector {
    private static final long WINDOW_MS = 1400L;
    private static final long COOLDOWN_MS = 650L;
    private static final long MIN_IMPULSE_GAP_MS = 90L;
    // Short ambiguity window: lets a possible third impulse arrive without making
    // a configured double gesture feel slow. This is the minimum compromise when
    // both double and triple gestures share the same prefix.
    private static final long DOUBLE_TRIPLE_AMBIGUITY_MS = 130L;
    private static final float BASE_SHAKE_THRESHOLD = 4.0f;
    private static final float BASE_LONG_THRESHOLD = 2.4f;
    private static final long MIN_LONG_DURATION_MS = 180L;

    private final Deque<Impulse> impulses = new ArrayDeque<>();
    private final Deque<Stroke> strokes = new ArrayDeque<>();
    private int lastAxis = 0;
    private int lastSign = 0;
    private long lastImpulseTime = -MIN_IMPULSE_GAP_MS;
    private Stroke activeStroke;
    private long lastEventTime = -COOLDOWN_MS;
    private long pendingDoubleSince = -1L;

    public GestureEvent addSample(MotionSample sample, float sensitivityFactor) {
        purge(sample.timeMs);
        float threshold = BASE_SHAKE_THRESHOLD * sensitivityFactor;
        float longThreshold = BASE_LONG_THRESHOLD * sensitivityFactor;

        float ax = Math.abs(sample.x);
        float ay = Math.abs(sample.y);
        int axis = ax >= ay ? 1 : 2;
        float dominant = axis == 1 ? ax : ay;
        int sign = axis == 1 ? Integer.signum((int) Math.signum(sample.x)) : Integer.signum((int) Math.signum(sample.y));

        if (dominant >= threshold && sign != 0) {
            if (axis != lastAxis) {
                lastAxis = axis;
                lastSign = 0;
            }
            if (sign != lastSign && sample.timeMs - lastImpulseTime >= MIN_IMPULSE_GAP_MS) {
                impulses.addLast(new Impulse(sample.timeMs, axis, sign, Math.min(1.0f, dominant / (threshold * 1.7f))));
                lastImpulseTime = sample.timeMs;
                lastSign = sign;
            }
        }

        handleLongStroke(sample, axis, dominant, sign, longThreshold);

        GestureEvent longEvent = detectLong(sample.timeMs);
        if (longEvent != null) return longEvent;
        return detectShake(sample.timeMs);
    }

    private void handleLongStroke(MotionSample s, int axis, float dominant, int sign, float threshold) {
        if (dominant >= threshold && sign != 0) {
            if (activeStroke == null || activeStroke.axis != axis || activeStroke.sign != sign) {
                if (activeStroke != null) finishStroke(s.timeMs);
                activeStroke = new Stroke(s.timeMs, s.timeMs, axis, sign, dominant);
            } else {
                activeStroke.endMs = s.timeMs;
                activeStroke.peak = Math.max(activeStroke.peak, dominant);
            }
        } else if (activeStroke != null && s.timeMs - activeStroke.endMs > 90L) {
            finishStroke(s.timeMs);
        }
    }

    private void finishStroke(long now) {
        if (activeStroke != null && activeStroke.endMs - activeStroke.startMs >= MIN_LONG_DURATION_MS) {
            strokes.addLast(activeStroke.copy());
        }
        activeStroke = null;
        purge(now);
    }

    private GestureEvent detectLong(long now) {
        if (now - lastEventTime < COOLDOWN_MS || strokes.size() < 2) return null;
        Stroke[] a = strokes.toArray(new Stroke[0]);
        Stroke b = a[a.length - 1];
        Stroke p = a[a.length - 2];
        if (b.axis == p.axis && b.sign == -p.sign) {
            if (b.axis == 1) {
                lastEventTime = now;
                strokes.clear();
                impulses.clear();
                return new GestureEvent(GestureType.LONG_HORIZONTAL, confidenceFor(b, p), now);
            } else if (b.axis == 2) {
                lastEventTime = now;
                strokes.clear();
                impulses.clear();
                return new GestureEvent(GestureType.LONG_VERTICAL, confidenceFor(b, p), now);
            }
        }
        return null;
    }

    private GestureEvent detectShake(long now) {
        if (now - lastEventTime < COOLDOWN_MS || impulses.isEmpty()) return null;
        Impulse[] a = impulses.toArray(new Impulse[0]);
        int n = a.length;
        if (n >= 3) {
            Impulse i1 = a[n - 3], i2 = a[n - 2], i3 = a[n - 1];
            if (i1.axis == i2.axis && i2.axis == i3.axis && i1.sign == -i2.sign && i2.sign == -i3.sign
                    && i3.timeMs - i1.timeMs <= 900L) {
                pendingDoubleSince = -1L;
                lastEventTime = now;
                impulses.clear();
                strokes.clear();
                GestureType type = i1.axis == 1 ? GestureType.HORIZONTAL_TRIPLE : GestureType.VERTICAL_TRIPLE;
                return new GestureEvent(type, Math.min(0.99f, 0.70f + (i1.strength + i2.strength + i3.strength) / 10f), now);
            }
        }
        if (n >= 2) {
            Impulse i1 = a[n - 2], i2 = a[n - 1];
            if (i1.axis == i2.axis && i1.sign == -i2.sign && i2.timeMs - i1.timeMs <= 800L) {
                if (pendingDoubleSince < 0L) {
                    pendingDoubleSince = i2.timeMs;
                }
                if (now - pendingDoubleSince < DOUBLE_TRIPLE_AMBIGUITY_MS) return null;
                pendingDoubleSince = -1L;
                lastEventTime = now;
                impulses.clear();
                strokes.clear();
                GestureType type = i1.axis == 1 ? GestureType.HORIZONTAL_DOUBLE : GestureType.VERTICAL_DOUBLE;
                return new GestureEvent(type, Math.min(0.98f, 0.72f + (i1.strength + i2.strength) / 8f), now);
            }
        }
        if (pendingDoubleSince >= 0L && now - pendingDoubleSince >= DOUBLE_TRIPLE_AMBIGUITY_MS) {
            pendingDoubleSince = -1L;
        }
        return null;
    }

    private float confidenceFor(Stroke a, Stroke b) {
        long duration = (a.endMs - a.startMs) + (b.endMs - b.startMs);
        float durationScore = Math.min(1.0f, duration / 1200f);
        float power = Math.min(1.0f, (a.peak + b.peak) / 10f);
        return Math.min(0.99f, 0.65f + 0.2f * durationScore + 0.14f * power);
    }

    private void purge(long now) {
        while (!impulses.isEmpty() && now - impulses.peekFirst().timeMs > WINDOW_MS) impulses.removeFirst();
        while (!strokes.isEmpty() && now - strokes.peekFirst().endMs > WINDOW_MS) strokes.removeFirst();
    }

    private static final class Impulse {
        final long timeMs;
        final int axis;
        final int sign;
        final float strength;
        Impulse(long timeMs, int axis, int sign, float strength) {
            this.timeMs = timeMs; this.axis = axis; this.sign = sign; this.strength = strength;
        }
    }

    private static final class Stroke {
        final long startMs;
        long endMs;
        final int axis;
        final int sign;
        float peak;
        Stroke(long startMs, long endMs, int axis, int sign, float peak) {
            this.startMs = startMs; this.endMs = endMs; this.axis = axis; this.sign = sign; this.peak = peak;
        }
        Stroke copy() { return new Stroke(startMs, endMs, axis, sign, peak); }
    }
}
