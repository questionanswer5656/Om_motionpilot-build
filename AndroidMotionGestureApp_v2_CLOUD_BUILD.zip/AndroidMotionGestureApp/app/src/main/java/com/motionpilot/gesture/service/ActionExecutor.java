package com.motionpilot.gesture.service;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;

import com.motionpilot.gesture.app.AppPreferences;
import com.motionpilot.gesture.model.ActionType;

public final class ActionExecutor {
    private static final String TAG = "MotionPilot";
    private final Context context;
    private final AppPreferences prefs;
    private final CameraManager cameraManager;
    private String torchCameraId;

    public ActionExecutor(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = new AppPreferences(this.context);
        cameraManager = (CameraManager) this.context.getSystemService(Context.CAMERA_SERVICE);
        findTorch();
    }

    public boolean execute(ActionType action, String payload) {
        try {
            switch (action) {
                case NONE: return true;
                case FLASHLIGHT_TOGGLE: return toggleTorch();
                case FLASHLIGHT_BRIGHTER: return changeTorchStrength(+1);
                case FLASHLIGHT_DIMMER: return changeTorchStrength(-1);
                case VOLUME_UP: return adjustVolume(AudioManager.ADJUST_RAISE);
                case VOLUME_DOWN: return adjustVolume(AudioManager.ADJUST_LOWER);
                case RINGER_NORMAL: return setRinger(AudioManager.RINGER_MODE_NORMAL);
                case RINGER_VIBRATE: return setRinger(AudioManager.RINGER_MODE_VIBRATE);
                case RINGER_SILENT: return setRinger(AudioManager.RINGER_MODE_SILENT);
                case CALL_NUMBER: return call(payload);
                case OPEN_APP: return openPackage(payload);
                case SCREENSHOT_UNSUPPORTED:
                    Log.i(TAG, "Screenshot requires a user-approved screen capture flow and is intentionally not silent.");
                    return false;
                default: return false;
            }
        } catch (Exception e) {
            Log.e(TAG, "Action failed: " + action, e);
            return false;
        }
    }

    private void findTorch() {
        if (cameraManager == null) return;
        try {
            for (String id : cameraManager.getCameraIdList()) {
                CameraCharacteristics cc = cameraManager.getCameraCharacteristics(id);
                Boolean flash = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = cc.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(flash) && (facing == null || facing == CameraCharacteristics.LENS_FACING_BACK)) {
                    torchCameraId = id;
                    return;
                }
            }
        } catch (CameraAccessException ignored) { }
    }

    private boolean toggleTorch() throws CameraAccessException {
        if (torchCameraId == null || cameraManager == null) return false;
        // We keep a local preference for state because direct torch status is not exposed on all API levels.
        boolean on = prefs.prefsForInternalOnly().getBoolean("torch_state", false);
        cameraManager.setTorchMode(torchCameraId, !on);
        prefs.prefsForInternalOnly().edit().putBoolean("torch_state", !on).apply();
        return true;
    }

    private boolean changeTorchStrength(int direction) throws CameraAccessException {
        if (torchCameraId == null || cameraManager == null) return false;
        if (Build.VERSION.SDK_INT < 33) {
            // No strength API. Treat brightness gestures as a simple on/off fallback.
            return toggleTorch();
        }
        int max = cameraManager.getCameraCharacteristics(torchCameraId).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL);
        if (max <= 0) return false;
        int current = prefs.prefsForInternalOnly().getInt("torch_strength", 1);
        int next = Math.max(1, Math.min(max, current + direction));
        cameraManager.turnOnTorchWithStrengthLevel(torchCameraId, next);
        prefs.prefsForInternalOnly().edit().putBoolean("torch_state", true).putInt("torch_strength", next).apply();
        return true;
    }

    private boolean adjustVolume(int direction) {
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return false;
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI);
        return true;
    }

    private boolean setRinger(int mode) {
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return false;
        am.setRingerMode(mode);
        return true;
    }

    private boolean call(String raw) {
        if (raw == null) return false;
        String number = raw.trim();
        if (number.isEmpty()) return false;
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (context.checkSelfPermission(android.Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            context.startActivity(intent);
            return true;
        }
        Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)));
        dial.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(dial);
        return true;
    }

    private boolean openPackage(String pkg) {
        if (pkg == null || pkg.trim().isEmpty()) return false;
        PackageManager pm = context.getPackageManager();
        Intent launch = pm.getLaunchIntentForPackage(pkg.trim());
        if (launch == null) return false;
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(launch);
        return true;
    }
}
