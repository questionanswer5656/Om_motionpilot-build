package com.motionpilot.gesture;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.motionpilot.gesture.app.AppPreferences;
import com.motionpilot.gesture.compat.PlatformCompatibility;
import com.motionpilot.gesture.app.DeviceCapabilities;
import com.motionpilot.gesture.app.OemGuidance;
import com.motionpilot.gesture.app.PermissionManager;
import com.motionpilot.gesture.model.ActionType;
import com.motionpilot.gesture.model.GestureType;
import com.motionpilot.gesture.service.GestureEngineService;

public final class MainActivity extends Activity {
    private AppPreferences prefs;
    private DeviceCapabilities caps;
    private LinearLayout content;
    private TextView status;
    private int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = new AppPreferences(this);
        caps = new DeviceCapabilities(this);
        buildUi();
        requestNotificationPermissionIfNeeded();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11,13,18));
        root.setPadding(dp(14), dp(12), dp(14), dp(8));

        TextView title = text("MotionPilot", 26, Color.WHITE);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title, lp(-1, dp(44)));

        status = text("", 15, Color.WHITE);
        root.addView(status, lp(-1, dp(34)));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        Button h = button("Horizontal");
        Button v = button("Vertical");
        Button s = button("Edge & Settings");
        tabs.addView(h, weightLp(1)); tabs.addView(v, weightLp(1)); tabs.addView(s, weightLp(1));
        root.addView(tabs, lp(-1, dp(48)));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(content);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));

        h.setOnClickListener(x -> showGesturePanel(true));
        v.setOnClickListener(x -> showGesturePanel(false));
        s.setOnClickListener(x -> showSettingsPanel());

        setContentView(root);
        showGesturePanel(true);
        refreshStatus();
    }

    private void refreshStatus() {
        if (status == null) return;
        if (!prefs.isEngineEnabled()) {
            status.setText(getString(R.string.engine_off));
            status.setTextColor(Color.rgb(242,201,76));
        } else if (!caps.hasMotionSensor()) {
            status.setText(getString(R.string.engine_restricted));
            status.setTextColor(Color.rgb(255,107,107));
        } else {
            status.setText(getString(R.string.engine_active) + " • " + PlatformCompatibility.generationLabel() + " • " + caps.manufacturer);
            status.setTextColor(Color.rgb(88,214,141));
        }
    }

    private void showGesturePanel(boolean horizontal) {
        content.removeAllViews();
        addInfoCard();
        GestureType[] types = horizontal
                ? new GestureType[]{GestureType.HORIZONTAL_DOUBLE, GestureType.HORIZONTAL_TRIPLE, GestureType.LONG_HORIZONTAL, GestureType.LONG_HORIZONTAL_2X, GestureType.LONG_HORIZONTAL_3X}
                : new GestureType[]{GestureType.VERTICAL_DOUBLE, GestureType.VERTICAL_TRIPLE, GestureType.LONG_VERTICAL, GestureType.LONG_VERTICAL_2X, GestureType.LONG_VERTICAL_3X};
        for (GestureType t : types) addGestureRow(t);
    }

    private void addInfoCard() {
        LinearLayout card = card();
        TextView a = text(getString(R.string.how_it_works), 15, Color.WHITE);
        TextView b = text(getString(R.string.background_note), 12, Color.rgb(169,175,191));
        card.addView(a, lp(-1, -2)); card.addView(b, lp(-1, -2));
        content.addView(card, lp(-1, -2));
        Switch engine = new Switch(this);
        engine.setText(prefs.isEngineEnabled() ? getString(R.string.disable_engine) : getString(R.string.enable_engine));
        engine.setTextColor(Color.WHITE);
        engine.setChecked(prefs.isEngineEnabled());
        engine.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.setEngineEnabled(isChecked);
            Intent i = new Intent(this, GestureEngineService.class);
            if (isChecked) {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
                engine.setText(getString(R.string.disable_engine));
                Toast.makeText(this, "Gesture Engine armed", Toast.LENGTH_SHORT).show();
            } else {
                i.setAction(GestureEngineService.ACTION_STOP);
                startService(i);
                engine.setText(getString(R.string.enable_engine));
            }
            refreshStatus();
        });
        content.addView(engine, lp(-1, dp(50)));
    }

    private void addGestureRow(GestureType type) {
        LinearLayout card = card();
        TextView name = text(type.displayName(), 16, Color.WHITE);
        card.addView(name, lp(-1, dp(32)));
        Button action = button(prefs.getGestureAction(type).displayName());
        card.addView(action, lp(-1, dp(44)));
        action.setOnClickListener(v -> chooseAction(type, action));
        content.addView(card, lp(-1, -2));
    }

    private void chooseAction(GestureType type, Button target) {
        ActionType[] actions = ActionType.values();
        String[] labels = new String[actions.length];
        for (int i = 0; i < actions.length; i++) labels[i] = actions[i].displayName();
        new android.app.AlertDialog.Builder(this)
                .setTitle(type.displayName())
                .setItems(labels, (d, which) -> configureAction(type, actions[which], target))
                .show();
    }

    private void configureAction(GestureType type, ActionType action, Button target) {
        if (action == ActionType.CALL_NUMBER || action == ActionType.OPEN_APP) {
            EditText input = new EditText(this);
            input.setSingleLine(true);
            input.setText(prefs.getPayload(type));
            input.setHint(action == ActionType.CALL_NUMBER ? "+91..." : "com.example.app");
            new android.app.AlertDialog.Builder(this)
                    .setTitle(action.displayName())
                    .setMessage(action == ActionType.CALL_NUMBER ? "Enter the phone number." : "Enter the installed app package name.")
                    .setView(input)
                    .setPositiveButton("Save", (d, w) -> {
                        prefs.setPayload(type, input.getText().toString().trim());
                        prefs.setGestureAction(type, action);
                        target.setText(action.displayName());
                        if (action == ActionType.CALL_NUMBER && !PermissionManager.callGranted(this)) {
                            PermissionManager.requestRuntime(this, Manifest.permission.CALL_PHONE, 404);
                        }
                    })
                    .setNegativeButton("Cancel", null)
                    .show();
        } else {
            prefs.setGestureAction(type, action);
            target.setText(action.displayName());
            if (action == ActionType.SCREENSHOT_UNSUPPORTED) {
                Toast.makeText(this, "Android requires a user-approved capture flow for silent screenshots.", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void showSettingsPanel() {
        content.removeAllViews();
        addInfoCard();

        LinearLayout card = card();
        TextView h = text("Edge controls", 18, Color.WHITE);
        card.addView(h, lp(-1, dp(34)));
        Switch edge = new Switch(this);
        edge.setText(getString(R.string.edge_overlay));
        edge.setTextColor(Color.WHITE);
        edge.setChecked(prefs.isEdgeEnabled());
        edge.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.setEdgeEnabled(isChecked);
            if (isChecked && !PermissionManager.overlayGranted(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
                startActivity(i);
                Toast.makeText(this, "Allow overlay permission, then return and enable again.", Toast.LENGTH_LONG).show();
                edge.setChecked(false);
            } else if (prefs.isEngineEnabled()) {
                restartService();
            }
        });
        card.addView(edge, lp(-1, dp(48)));
        card.addView(text(getString(R.string.left_edge), 13, Color.rgb(169,175,191)), lp(-1, dp(28)));
        card.addView(text(getString(R.string.right_edge), 13, Color.rgb(169,175,191)), lp(-1, dp(28)));
        content.addView(card, lp(-1, -2));

        Button health = button(getString(R.string.background_health));
        health.setOnClickListener(v -> showHealth());
        content.addView(health, lp(-1, dp(46)));

        Button oem = button(getString(R.string.oem_optimization));
        oem.setOnClickListener(v -> showOem());
        content.addView(oem, lp(-1, dp(46)));

        Button battery = button(getString(R.string.open_battery));
        battery.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)));
        content.addView(battery, lp(-1, dp(46)));

        Button appSettings = button(getString(R.string.open_app_settings));
        appSettings.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()))));
        content.addView(appSettings, lp(-1, dp(46)));

        Button reset = button(getString(R.string.reset_defaults));
        reset.setOnClickListener(v -> {
            prefs.resetGestureDefaults();
            Toast.makeText(this, "Gesture defaults reset", Toast.LENGTH_SHORT).show();
        });
        content.addView(reset, lp(-1, dp(46)));

        Button test = button(getString(R.string.run_test));
        test.setOnClickListener(v -> testEngine());
        content.addView(test, lp(-1, dp(46)));
    }

    private void showHealth() {
        String msg = "Android " + caps.apiLevel + "\nManufacturer: " + caps.manufacturer + "\nModel: " + caps.model
                + "\nMotion sensor: " + (caps.hasMotionSensor() ? "YES" : "NO")
                + "\nProximity: " + (caps.hasProximity() ? "YES" : "NO")
                + "\nWalking sensor: " + (caps.hasWalkingSensor() ? "YES" : "NO")
                + "\nOverlay: " + (PermissionManager.overlayGranted(this) ? "YES" : "NO")
                + "\nNotifications: " + (PermissionManager.notificationsGranted(this) ? "YES" : "NO")
                + "\nEngine flag: " + (prefs.isEngineEnabled() ? "ON" : "OFF");
        new android.app.AlertDialog.Builder(this).setTitle("Background Health").setMessage(msg).setPositiveButton("OK", null).show();
    }

    private void showOem() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("OEM guidance")
                .setMessage(OemGuidance.forDevice(caps))
                .setPositiveButton("OK", null)
                .show();
    }

    private void testEngine() {
        if (!prefs.isEngineEnabled()) {
            Toast.makeText(this, "Enable Gesture Engine first.", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(this, GestureEngineService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        Toast.makeText(this, "Engine start requested. Lock the phone and test a configured gesture.", Toast.LENGTH_LONG).show();
    }

    private void restartService() {
        Intent i = new Intent(this, GestureEngineService.class).setAction(GestureEngineService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && !PermissionManager.notificationsGranted(this)) {
            PermissionManager.requestRuntime(this, Manifest.permission.POST_NOTIFICATIONS, 401);
        }
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(12), dp(14), dp(12));
        l.setBackgroundColor(Color.rgb(21,25,34));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(7), 0, dp(7));
        l.setLayoutParams(p);
        return l;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private LinearLayout.LayoutParams weightLp(float weight) { return new LinearLayout.LayoutParams(0, -1, weight); }
}
