package com.motionpilot.gesture.model;

public enum ActionType {
    NONE,
    FLASHLIGHT_TOGGLE,
    FLASHLIGHT_BRIGHTER,
    FLASHLIGHT_DIMMER,
    VOLUME_UP,
    VOLUME_DOWN,
    RINGER_NORMAL,
    RINGER_VIBRATE,
    RINGER_SILENT,
    CALL_NUMBER,
    OPEN_APP,
    SCREENSHOT_UNSUPPORTED;

    public String displayName() {
        switch (this) {
            case NONE: return "Do nothing";
            case FLASHLIGHT_TOGGLE: return "Flashlight toggle";
            case FLASHLIGHT_BRIGHTER: return "Flashlight brighter";
            case FLASHLIGHT_DIMMER: return "Flashlight dimmer";
            case VOLUME_UP: return "Volume up";
            case VOLUME_DOWN: return "Volume down";
            case RINGER_NORMAL: return "Ringer normal";
            case RINGER_VIBRATE: return "Vibrate";
            case RINGER_SILENT: return "Silent";
            case CALL_NUMBER: return "Call saved number";
            case OPEN_APP: return "Open app package";
            case SCREENSHOT_UNSUPPORTED: return "Screenshot (permission flow required)";
            default: return name();
        }
    }
}
