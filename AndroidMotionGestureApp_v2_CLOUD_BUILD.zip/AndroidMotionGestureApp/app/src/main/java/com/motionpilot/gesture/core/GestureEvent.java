package com.motionpilot.gesture.core;

import com.motionpilot.gesture.model.GestureType;

public final class GestureEvent {
    public final GestureType type;
    public final float confidence;
    public final long detectedAtMs;

    public GestureEvent(GestureType type, float confidence, long detectedAtMs) {
        this.type = type;
        this.confidence = confidence;
        this.detectedAtMs = detectedAtMs;
    }
}
