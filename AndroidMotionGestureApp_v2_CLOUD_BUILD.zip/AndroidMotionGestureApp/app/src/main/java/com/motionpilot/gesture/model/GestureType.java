package com.motionpilot.gesture.model;

public enum GestureType {
    HORIZONTAL_DOUBLE,
    HORIZONTAL_TRIPLE,
    VERTICAL_DOUBLE,
    VERTICAL_TRIPLE,
    LONG_VERTICAL,
    LONG_HORIZONTAL,
    LONG_HORIZONTAL_2X,
    LONG_HORIZONTAL_3X,
    LONG_VERTICAL_2X,
    LONG_VERTICAL_3X;

    public String displayName() {
        switch (this) {
            case HORIZONTAL_DOUBLE: return "Double Horizontal Shake";
            case HORIZONTAL_TRIPLE: return "Triple Horizontal Shake";
            case VERTICAL_DOUBLE: return "Double Vertical Shake";
            case VERTICAL_TRIPLE: return "Triple Vertical Shake";
            case LONG_VERTICAL: return "Long Up → Down";
            case LONG_HORIZONTAL: return "Long Left → Right";
            case LONG_HORIZONTAL_2X: return "2× Long Horizontal";
            case LONG_HORIZONTAL_3X: return "3× Long Horizontal";
            case LONG_VERTICAL_2X: return "2× Long Vertical";
            case LONG_VERTICAL_3X: return "3× Long Vertical";
            default: return name();
        }
    }
}
