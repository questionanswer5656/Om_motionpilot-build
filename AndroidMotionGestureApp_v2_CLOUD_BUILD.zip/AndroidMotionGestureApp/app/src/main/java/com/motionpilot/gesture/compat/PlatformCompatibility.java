package com.motionpilot.gesture.compat;

import android.os.Build;

/** Centralized Android-version behavior flags used by the app UI/service. */
public final class PlatformCompatibility {
    private PlatformCompatibility() {}

    public static int api() { return Build.VERSION.SDK_INT; }
    public static boolean needsNotificationRuntimePermission() { return Build.VERSION.SDK_INT >= 33; }
    public static boolean foregroundServiceTypesRequired() { return Build.VERSION.SDK_INT >= 34; }
    public static boolean bootRecoveryNeedsExtraValidation() { return Build.VERSION.SDK_INT >= 34; }
    public static boolean taskManagerStopExists() { return Build.VERSION.SDK_INT >= 33; }
    public static boolean android16RulesActive() { return Build.VERSION.SDK_INT >= 36; }
    public static boolean android17RulesActive() { return Build.VERSION.SDK_INT >= 37; }

    public static String generationLabel() {
        if (Build.VERSION.SDK_INT >= 37) return "Android 17";
        if (Build.VERSION.SDK_INT >= 36) return "Android 16";
        if (Build.VERSION.SDK_INT >= 35) return "Android 15";
        if (Build.VERSION.SDK_INT >= 34) return "Android 14";
        if (Build.VERSION.SDK_INT >= 33) return "Android 13";
        if (Build.VERSION.SDK_INT >= 31) return "Android 12";
        return "Android 11";
    }
}
