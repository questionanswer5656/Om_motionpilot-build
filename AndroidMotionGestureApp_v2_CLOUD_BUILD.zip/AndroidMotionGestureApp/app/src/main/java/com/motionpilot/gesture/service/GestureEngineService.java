package com.motionpilot.gesture.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.Log;

import com.motionpilot.gesture.MainActivity;
import com.motionpilot.gesture.R;
import com.motionpilot.gesture.app.AppPreferences;
import com.motionpilot.gesture.app.DeviceCapabilities;
import com.motionpilot.gesture.core.GestureEvent;
import com.motionpilot.gesture.core.MotionSample;
import com.motionpilot.gesture.core.SensorGestureDetector;
import com.motionpilot.gesture.model.GestureType;

public final class GestureEngineService extends Service implements SensorEventListener {
    public static final String ACTION_START = "com.motionpilot.gesture.START";
    public static final String ACTION_STOP = "com.motionpilot.gesture.STOP";
    private static final String CHANNEL_ID = "gesture_engine";
    private static final int NOTIFICATION_ID = 4107;
    private static final String TAG = "MotionPilot";

    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor proximity;
    private Sensor stepDetector;
    private SensorGestureDetector detector;
    private AppPreferences prefs;
    private ActionExecutor executor;
    private EdgeOverlayController edgeOverlay;
    private Handler handler;

    private final float[] gravity = new float[3];
    private boolean gravityInitialized;
    private boolean pocketHint;
    private long lastStepMs;
    private long highRateUntil;
    private boolean running;
    private boolean highRateActive;

    @Override public void onCreate() {
        super.onCreate();
        prefs = new AppPreferences(this);
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        detector = new SensorGestureDetector();
        executor = new ActionExecutor(this);
        edgeOverlay = new EdgeOverlayController(this);
        handler = new Handler(Looper.getMainLooper());
        ensureNotificationChannel();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            prefs.setEngineEnabled(false);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!prefs.isEngineEnabled()) {
            stopSelf();
            return START_NOT_STICKY;
        }
        promoteToForeground();
        startSensors();
        edgeOverlay.startIfAllowed();
        running = true;
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        stopSensors();
        if (edgeOverlay != null) edgeOverlay.stop();
        super.onDestroy();
    }

    @Override public void onTaskRemoved(Intent rootIntent) {
        // Recent Apps removal is not an engine stop. The service is declared stopWithTask=false.
        if (prefs.isEngineEnabled() && running) {
            handler.postDelayed(this::restartSensorsIfNeeded, 250L);
        }
        super.onTaskRemoved(rootIntent);
    }

    private void restartSensorsIfNeeded() {
        if (prefs.isEngineEnabled() && !running) startSensors();
    }

    private void promoteToForeground() {
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, n);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(this, 100, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, GestureEngineService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 101, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle(getString(R.string.notification_title))
                .setContentText(getString(R.string.notification_text))
                .setContentIntent(openPi)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(0, "Stop", stopPi).build());
        return b.build();
    }

    private void ensureNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Gesture Engine", NotificationManager.IMPORTANCE_LOW);
                ch.setDescription("Persistent notification for the user-enabled gesture engine.");
                nm.createNotificationChannel(ch);
            }
        }
    }

    private void startSensors() {
        if (sensorManager == null || accelerometer == null) {
            DeviceCapabilities c = new DeviceCapabilities(this);
            accelerometer = c.accelerometer;
            proximity = c.proximity;
            stepDetector = c.stepDetector;
        }
        if (accelerometer == null) return;
        sensorManager.unregisterListener(this);
        sensorManager.registerListener(this, accelerometer, android.hardware.SensorManager.SENSOR_DELAY_UI);
        if (proximity != null) sensorManager.registerListener(this, proximity, android.hardware.SensorManager.SENSOR_DELAY_NORMAL);
        if (stepDetector != null && checkSelfPermission(android.Manifest.permission.ACTIVITY_RECOGNITION) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            sensorManager.registerListener(this, stepDetector, android.hardware.SensorManager.SENSOR_DELAY_NORMAL);
        }
        running = true;
    }

    private void stopSensors() {
        if (sensorManager != null) sensorManager.unregisterListener(this);
    }

    @Override public void onSensorChanged(SensorEvent event) {
        long now = System.currentTimeMillis();
        if (event.sensor.getType() == Sensor.TYPE_PROXIMITY) {
            float max = event.sensor.getMaximumRange();
            pocketHint = max > 0 && event.values.length > 0 && event.values[0] < max * 0.35f;
            return;
        }
        if (event.sensor.getType() == Sensor.TYPE_STEP_DETECTOR) {
            lastStepMs = now;
            return;
        }
        if (event.sensor.getType() != Sensor.TYPE_ACCELEROMETER || event.values.length < 3) return;

        float x = event.values[0], y = event.values[1], z = event.values[2];
        final float alpha = 0.80f;
        if (!gravityInitialized) {
            gravity[0] = x; gravity[1] = y; gravity[2] = z;
            gravityInitialized = true;
        } else {
            gravity[0] = alpha * gravity[0] + (1 - alpha) * x;
            gravity[1] = alpha * gravity[1] + (1 - alpha) * y;
            gravity[2] = alpha * gravity[2] + (1 - alpha) * z;
        }
        float lx = x - gravity[0];
        float ly = y - gravity[1];
        float lz = z - gravity[2];
        float magnitude = (float) Math.sqrt(lx * lx + ly * ly + lz * lz);
        if (magnitude > 1.8f) highRateUntil = now + 1000L;
        float sensitivityFactor = 1.0f;
        if (now - lastStepMs < 2200L) sensitivityFactor *= 1.22f;
        if (pocketHint) sensitivityFactor *= 1.18f;
        MotionSample s = new MotionSample(now, lx, ly, lz);
        GestureEvent result = detector.addSample(s, sensitivityFactor);
        if (result != null && result.confidence >= 0.72f) executeGesture(result.type);
        if (highRateUntil > now && !highRateActive) ensureHigherRate();
    }

    private void ensureHigherRate() {
        if (sensorManager == null || accelerometer == null || highRateActive) return;
        highRateActive = true;
        sensorManager.unregisterListener(this);
        sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
        handler.postDelayed(() -> {
            if (prefs.isEngineEnabled()) {
                sensorManager.unregisterListener(this);
                sensorManager.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_UI);
            }
            highRateActive = false;
        }, 1100L);
    }

    private void executeGesture(GestureType type) {
        com.motionpilot.gesture.model.ActionType action = prefs.getGestureAction(type);
        String payload = prefs.getPayload(type);
        boolean ok = executor.execute(action, payload);
        if (!ok) Log.w(TAG, "Gesture action failed: " + type + " / " + action);
    }

    public void onLeftEdgeSwipe(boolean up) {
        executor.execute(up ? com.motionpilot.gesture.model.ActionType.FLASHLIGHT_BRIGHTER : com.motionpilot.gesture.model.ActionType.FLASHLIGHT_DIMMER, "");
    }

    public void onRightEdgeSwipe(boolean up) {
        executor.execute(up ? com.motionpilot.gesture.model.ActionType.VOLUME_UP : com.motionpilot.gesture.model.ActionType.VOLUME_DOWN, "");
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) { }

    @Override public IBinder onBind(Intent intent) { return null; }
}
