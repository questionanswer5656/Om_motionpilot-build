package com.motionpilot.gesture.app;

public final class OemGuidance {
    private OemGuidance() {}

    public static String forDevice(DeviceCapabilities c) {
        if (c.isSamsung()) {
            return "Samsung: keep MotionPilot out of Sleeping/Deep Sleeping apps. Check Settings → Battery → Background usage limits. Allow notifications and keep the foreground service visible.";
        }
        if (c.isXiaomiFamily()) {
            return "Xiaomi/Redmi/POCO: check Battery → App battery saver and enable Background autostart where available. Avoid Deep sleep/Restricted mode for MotionPilot.";
        }
        if (c.isOnePlus()) {
            return "OnePlus: check Battery → More settings / Battery optimization and allow background activity for MotionPilot.";
        }
        if (c.isOppo()) {
            return "OPPO: check Battery → More settings / Startup manager and allow background activity/autostart for MotionPilot.";
        }
        if (c.isVivo()) {
            return "vivo: check Battery → Background power consumption / Autostart and allow MotionPilot to run in the background.";
        }
        if (c.isRealme()) {
            return "realme: check Battery → App battery management and allow background activity/autostart for MotionPilot.";
        }
        if (c.isMotorola()) {
            return "Motorola: check Battery → App standby / Background restriction and keep MotionPilot unrestricted where available.";
        }
        if (c.isHonor()) {
            return "HONOR: check Battery → App launch and allow MotionPilot to run automatically and in the background.";
        }
        return "Android: keep the Gesture Engine's foreground service enabled, allow notifications, and avoid putting MotionPilot into a restricted battery state.";
    }
}
