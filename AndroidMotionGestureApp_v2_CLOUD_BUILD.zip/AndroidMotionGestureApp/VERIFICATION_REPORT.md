# MotionPilot Verification Report

Date: 2026-10-08

## Checks completed

1. Parsed all Android XML resource/manifest files successfully.
2. Checked all Java source files for balanced braces and package declarations.
3. Compiled the platform-independent gesture model and recognizer with `javac`.
4. Ran synthetic tests for:
   - double horizontal gesture
   - triple horizontal gesture
   - long horizontal gesture
   - rejection of small movement noise
5. Fixed a recognizer initialization bug that dropped the first impulse.
6. Fixed double-vs-triple ambiguity by adding a short 130 ms ambiguity window, preserving immediate-feeling response while allowing a third impulse to win.
7. Fixed high-rate sensor switching so it is not repeatedly re-registered for every sensor event.
8. Moved persistent configuration to device-protected storage so boot/locked-boot recovery can read the enabled state before first unlock.
9. Added Android-version behavior helper and OEM guidance.
10. Rechecked XML after manifest patch.

## Build-environment limitation

The artifact environment has no Android SDK or Android Gradle Plugin cache, and outbound package downloads are unavailable. Therefore a full APK/Gradle build could not be executed here. The project is configured for AGP 9.4.0 / Gradle 9.6.0 / API 37 / Java 17 and should be opened in a matching Android Studio installation with the required Android SDK installed.

## Important production limitations

- Android explicit Force Stop / Task Manager Stop cannot be bypassed by a normal Play Store app.
- `specialUse` foreground service use is subject to Google Play review.
- Edge overlay behavior on secure lock screens is device/OS dependent.
- Silent cross-app screenshots are intentionally not implemented because modern Android requires a user-approved capture flow.
- Android 17 background audio/volume behavior must be certified on physical devices.
