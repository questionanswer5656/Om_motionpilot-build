# MotionPilot — Android Motion Gesture App

MotionPilot is an Android-only prototype/production-starting project implementing the requirements in `Android_Motion_Gesture_App_Requirements_v1_FINAL.docx`.

## Build target

- Minimum Android: API 30 (Android 11)
- Target/compile: API 37 (Android 17)
- Java: 17
- Android Gradle Plugin: 9.4.0
- Gradle: 9.6.0
- No AndroidX dependency is required by the current source tree.

## Main behavior

1. User enables Gesture Engine once.
2. A foreground service becomes the persistent engine.
3. Recent Apps dismissal is separate from the service lifecycle (`stopWithTask=false`).
4. Boot receiver restores the engine when the saved enabled state is true and Android permits the start.
5. Motion recognition uses deliberate horizontal/vertical patterns, dynamic thresholds, pocket proximity hints and walking-step hints.
6. Safe actions are executed immediately after a high-confidence gesture.
7. Edge overlay adds left-edge flashlight-brightness and right-edge volume controls when overlay permission is granted.

## Important platform boundary

A normal Play Store app cannot defeat Android's explicit Force Stop / Task Manager Stop. The project therefore does not attempt to use hidden accessibility, device-admin, VPN, or other persistence loopholes. The engine instead uses documented foreground-service and boot-recovery paths, plus OEM guidance.

## Current action coverage

Implemented: flashlight toggle/brightness fallback, volume up/down, ringer normal/vibrate/silent, call-or-dial saved number, open installed app by package name.

Screenshot is deliberately marked unsupported in silent mode because current Android requires a user-approved screen-capture flow for cross-app screenshots.

## Android 17 note

Android 17 applies stronger rules to background audio interactions. The service is started by visible user interaction in the normal setup flow, so the project is designed around a user-initiated foreground service. Background audio/volume behavior still has to be certified on real Android 17 devices.

## Device certification required before Play release

Test at minimum on Google Pixel, Samsung Galaxy, Xiaomi/Redmi/POCO, OnePlus, OPPO, vivo, realme, Motorola and HONOR across Android 11–17 where available. Verify: screen off, locked, Recent Apps Clear All, reboot, battery saver, OEM sleep restrictions, walking, pocket use, false-trigger rate, and each action.

## Verification performed in the artifact environment

The platform-independent gesture recognition classes were compiled with `javac` and exercised with a synthetic self-test covering double/triple horizontal recognition, long horizontal recognition and rejection of small movement noise. Android UI/service compilation still requires a local Android SDK installation; the artifact was generated with current AGP/Gradle settings but this environment does not contain the Android SDK toolchain.
