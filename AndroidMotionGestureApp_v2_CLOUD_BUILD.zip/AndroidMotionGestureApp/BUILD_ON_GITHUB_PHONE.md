# Build MotionPilot APK using only an Android phone

1. Create an empty GitHub repository, e.g. `motionpilot-build`.
2. Put this project in that repository.
3. GitHub Actions will run the workflow in `.github/workflows/android.yml`.
4. Open Actions -> Build MotionPilot APK -> latest run.
5. Open Artifacts and download `MotionPilot-release-apk`.

No PC is required. The APK is built by the GitHub-hosted Linux runner.
